package edu.bit.ex.mapper;

import java.util.List;

import edu.bit.ex.vo.BoardVO;

public interface EMPMapper {

	
	public List<BoardVO> getList(BoardVO boardVO);
}
